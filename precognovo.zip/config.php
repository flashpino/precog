<?php
/**
 * PrecogNovo - Configurações Globais
 */

// --- MySQL ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'precognovo');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// --- InfluxDB ---
define('INFLUXDB_URL', 'https://snipex-influxdb.wwyweh.easypanel.host');
define('INFLUXDB_ORG', 'supera');
define('INFLUXDB_BUCKET', 'precog');
define('INFLUXDB_TOKEN', 'GNPpBsSAmqUGK5vd_omgbIkBHHlxyJSx3LxNTFlO1HyWNIp7aIfYls4RqjiH20XCQM9AAbQvI_lpI9tGyr9AAw==');

// --- Webhook n8n ---
define('N8N_WEBHOOK_URL', 'https://SEU_N8N_URL/webhook/precog-alert');

// --- Alertas ---
define('ALERT_COOLDOWN_MINUTES', 15); // Anti-spam: intervalo mínimo entre alertas iguais

// --- App ---
define('APP_NAME', 'PrecogSystem');
define('APP_URL', 'http://localhost/precognovo');
define('POLLING_INTERVAL_MS', 30000); // 30 segundos

// --- Sessão ---
define('SESSION_LIFETIME', 3600); // 1 hora para admin

// Timezone
date_default_timezone_set('America/Sao_Paulo');
