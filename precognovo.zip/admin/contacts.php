<?php
/**
 * Admin - CRUD de Contatos para Alertas
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

Auth::requireAdmin();

$msg = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $clientId = intval($_POST['client_id'] ?? 0);
        $name     = trim($_POST['name'] ?? '');
        $phone    = trim($_POST['phone'] ?? '');

        if ($clientId === 0 || empty($name) || empty($phone)) {
            $msg = 'Todos os campos são obrigatórios.'; $msgType = 'error';
        } else {
            Database::execute(
                "INSERT INTO contacts (client_id, name, phone) VALUES (?, ?, ?)",
                [$clientId, $name, $phone]
            );
            $msg = 'Contato cadastrado!'; $msgType = 'success';
        }
    }

    if ($action === 'update') {
        $id       = intval($_POST['id'] ?? 0);
        $clientId = intval($_POST['client_id'] ?? 0);
        $name     = trim($_POST['name'] ?? '');
        $phone    = trim($_POST['phone'] ?? '');
        $active   = isset($_POST['is_active']) ? 1 : 0;

        if ($id > 0 && !empty($name) && !empty($phone)) {
            Database::execute(
                "UPDATE contacts SET client_id=?, name=?, phone=?, is_active=? WHERE id=?",
                [$clientId, $name, $phone, $active, $id]
            );
            $msg = 'Contato atualizado!'; $msgType = 'success';
        }
    }

    if ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            Database::execute("DELETE FROM contacts WHERE id = ?", [$id]);
            $msg = 'Contato excluído!'; $msgType = 'success';
        }
    }
}

// Filtro por cliente
$filterClient = intval($_GET['client_id'] ?? 0);
$whereClause = $filterClient > 0 ? " WHERE co.client_id = $filterClient" : "";

$contacts = Database::query(
    "SELECT co.*, c.name as client_name, c.company FROM contacts co JOIN clients c ON co.client_id = c.id $whereClause ORDER BY co.created_at DESC"
);
$clients = Database::query("SELECT id, name, company FROM clients WHERE is_active = 1 ORDER BY name");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?> - Contatos</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="navbar-brand">
        <div class="icon-bars"><span></span><span></span><span></span><span></span></div>
        <?= APP_NAME ?>
    </div>
    <ul class="navbar-nav">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="clients.php">Clientes</a></li>
        <li><a href="sensors.php">Sensores</a></li>
        <li><a href="contacts.php" class="active">Contatos</a></li>
    </ul>
    <div class="navbar-right">
        <a href="dashboard.php?logout=1" class="btn btn-secondary btn-sm">Sair</a>
    </div>
</nav>

<main class="main-content">
    <div class="admin-header">
        <div>
            <h1>Contatos para Alertas</h1>
            <p style="color:var(--text-muted);font-size:0.85rem;margin-top:0.25rem;">Pessoas que receberão notificações via n8n</p>
        </div>
        <button class="btn btn-primary" onclick="openModal('create')">+ Novo Contato</button>
    </div>

    <!-- Filtro por cliente -->
    <div style="margin-bottom:1rem;display:flex;gap:0.75rem;align-items:center;">
        <label style="color:var(--text-secondary);font-size:0.85rem;">Filtrar por cliente:</label>
        <select class="form-control" style="width:auto;min-width:200px;" onchange="location.href='contacts.php' + (this.value ? '?client_id=' + this.value : '')">
            <option value="">Todos</option>
            <?php foreach ($clients as $cl): ?>
            <option value="<?= $cl['id'] ?>" <?= $filterClient == $cl['id'] ? 'selected' : '' ?>><?= sanitize($cl['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <?php if ($msg): ?>
    <div class="alert-msg <?= $msgType ?>"><?= sanitize($msg) ?></div>
    <?php endif; ?>

    <table class="data-table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Telefone</th>
                <th>Cliente</th>
                <th>Status</th>
                <th>Criado em</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($contacts)): ?>
            <tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:2rem;">Nenhum contato cadastrado</td></tr>
            <?php else: ?>
            <?php foreach ($contacts as $co): ?>
            <tr>
                <td><strong><?= sanitize($co['name']) ?></strong></td>
                <td style="font-family:var(--font-mono);font-size:0.9rem;"><?= sanitize($co['phone']) ?></td>
                <td><?= sanitize($co['client_name']) ?></td>
                <td><span class="status-badge <?= $co['is_active'] ? 'safe' : 'danger' ?>"><?= $co['is_active'] ? 'Ativo' : 'Inativo' ?></span></td>
                <td><?= formatDateBR($co['created_at']) ?></td>
                <td>
                    <div class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick='openModal("edit", <?= json_encode($co) ?>)'>Editar</button>
                        <form method="POST" style="display:inline" onsubmit="return confirm('Excluir este contato?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $co['id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</main>

<!-- Modal -->
<div class="modal-overlay" id="modal">
    <div class="modal">
        <h2 id="modal-title">Novo Contato</h2>
        <form method="POST">
            <input type="hidden" name="action" id="modal-action" value="create">
            <input type="hidden" name="id" id="modal-id" value="">
            <div class="form-group">
                <label>Cliente *</label>
                <select name="client_id" id="m-client" class="form-control" required>
                    <option value="">Selecione...</option>
                    <?php foreach ($clients as $cl): ?>
                    <option value="<?= $cl['id'] ?>"><?= sanitize($cl['name']) ?> <?= $cl['company'] ? '(' . sanitize($cl['company']) . ')' : '' ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Nome *</label>
                <input type="text" name="name" id="m-name" class="form-control" placeholder="João Silva" required>
            </div>
            <div class="form-group">
                <label>Telefone (WhatsApp) *</label>
                <input type="text" name="phone" id="m-phone" class="form-control" placeholder="+5511999999999" required>
            </div>
            <div class="form-group" id="fg-active" style="display:none">
                <label><input type="checkbox" name="is_active" id="m-active" checked> Ativo</label>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
                <button type="submit" class="btn btn-primary">Salvar</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(mode, data = {}) {
    document.getElementById('modal').classList.add('active');
    if (mode === 'edit') {
        document.getElementById('modal-title').textContent = 'Editar Contato';
        document.getElementById('modal-action').value = 'update';
        document.getElementById('modal-id').value = data.id;
        document.getElementById('m-client').value = data.client_id;
        document.getElementById('m-name').value = data.name;
        document.getElementById('m-phone').value = data.phone;
        document.getElementById('m-active').checked = data.is_active == 1;
        document.getElementById('fg-active').style.display = 'block';
    } else {
        document.getElementById('modal-title').textContent = 'Novo Contato';
        document.getElementById('modal-action').value = 'create';
        document.getElementById('modal-id').value = '';
        document.getElementById('m-client').value = '';
        document.getElementById('m-name').value = '';
        document.getElementById('m-phone').value = '';
        document.getElementById('fg-active').style.display = 'none';
    }
}
function closeModal() { document.getElementById('modal').classList.remove('active'); }
document.getElementById('modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });
</script>
</body>
</html>
