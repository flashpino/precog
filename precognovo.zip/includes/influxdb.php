<?php
/**
 * Cliente InfluxDB via API HTTP (Flux queries)
 */

require_once __DIR__ . '/../config.php';

class InfluxDB {

    /**
     * Executa uma query Flux no InfluxDB e retorna os dados parseados
     */
    public static function query($fluxQuery) {
        $url = INFLUXDB_URL . '/api/v2/query?org=' . urlencode(INFLUXDB_ORG);

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $fluxQuery,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Token ' . INFLUXDB_TOKEN,
                'Content-Type: application/vnd.flux',
                'Accept: application/csv',
            ],
            CURLOPT_SSL_VERIFYPEER => false,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            error_log("InfluxDB cURL error: " . $error);
            return [];
        }

        if ($httpCode !== 200) {
            error_log("InfluxDB HTTP error {$httpCode}: " . $response);
            return [];
        }

        return self::parseCSV($response);
    }

    /**
     * Retorna as últimas leituras de um sensor
     */
    public static function getLatestReading($deviceId) {
        $flux = 'from(bucket: "' . INFLUXDB_BUCKET . '")
            |> range(start: -5m)
            |> filter(fn: (r) => r["device_id"] == "' . $deviceId . '")
            |> filter(fn: (r) => r["_field"] == "temperature" or r["_field"] == "humidity")
            |> last()';

        $data = self::query($flux);
        $result = ['temperature' => null, 'humidity' => null, 'time' => null];

        foreach ($data as $row) {
            if (isset($row['_field']) && isset($row['_value'])) {
                $result[$row['_field']] = round(floatval($row['_value']), 1);
                $result['time'] = $row['_time'] ?? null;
            }
        }

        return $result;
    }

    /**
     * Retorna dados históricos para gráficos
     */
    public static function getHistory($deviceId, $range = '-24h', $field = 'temperature') {
        $window = '5m';
        if ($range === '-7d') $window = '30m';
        if ($range === '-30d') $window = '2h';

        $flux = 'from(bucket: "' . INFLUXDB_BUCKET . '")
            |> range(start: ' . $range . ')
            |> filter(fn: (r) => r["device_id"] == "' . $deviceId . '")
            |> filter(fn: (r) => r["_field"] == "' . $field . '")
            |> aggregateWindow(every: ' . $window . ', fn: mean, createEmpty: false)
            |> yield(name: "mean")';

        $data = self::query($flux);
        $result = [];

        foreach ($data as $row) {
            if (isset($row['_time']) && isset($row['_value'])) {
                $result[] = [
                    'time'  => $row['_time'],
                    'value' => round(floatval($row['_value']), 1),
                ];
            }
        }

        return $result;
    }

    /**
     * Verifica se o sensor está online (enviou dados nos últimos 2 minutos)
     */
    public static function isSensorOnline($deviceId) {
        $flux = 'from(bucket: "' . INFLUXDB_BUCKET . '")
            |> range(start: -2m)
            |> filter(fn: (r) => r["device_id"] == "' . $deviceId . '")
            |> count()';

        $data = self::query($flux);
        return !empty($data);
    }

    /**
     * Parseia o CSV retornado pela API do InfluxDB
     */
    private static function parseCSV($csv) {
        $lines = explode("\n", trim($csv));
        if (count($lines) < 2) return [];

        $results = [];
        $headers = [];

        foreach ($lines as $i => $line) {
            $line = trim($line);
            if (empty($line) || $line[0] === '#') continue;

            $cols = str_getcsv($line);

            if (empty($headers)) {
                $headers = $cols;
                continue;
            }

            if (count($cols) === count($headers)) {
                $row = array_combine($headers, $cols);
                // Ignora a coluna vazia de resultado e tabela
                unset($row[''], $row['result'], $row['table']);
                $results[] = $row;
            }
        }

        return $results;
    }
}
