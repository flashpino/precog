<?php
/**
 * Funções auxiliares gerais
 */

/**
 * Retorna JSON e encerra
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Sanitiza input
 */
function sanitize($value) {
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

/**
 * Formata data para exibição BR
 */
function formatDateBR($datetime) {
    if (empty($datetime)) return '-';
    $dt = new DateTime($datetime);
    return $dt->format('d/m/Y H:i');
}

/**
 * Formata data relativa (Hoje, Ontem, etc.)
 */
function formatDateRelative($datetime) {
    if (empty($datetime)) return '-';
    $dt = new DateTime($datetime);
    $now = new DateTime();
    $diff = $now->diff($dt);

    if ($diff->days === 0) return 'Hoje, ' . $dt->format('H:i');
    if ($diff->days === 1) return 'Ontem, ' . $dt->format('H:i');
    return $dt->format('d/m') . ', ' . $dt->format('H:i');
}

/**
 * Verifica se pode disparar um novo alerta (anti-spam)
 */
function canTriggerAlert($sensorId, $type) {
    require_once __DIR__ . '/db.php';
    
    $lastAlert = Database::queryOne(
        "SELECT created_at FROM alerts 
         WHERE sensor_id = ? AND type = ? 
         ORDER BY created_at DESC LIMIT 1",
        [$sensorId, $type]
    );

    if (!$lastAlert) return true;

    $lastTime = new DateTime($lastAlert['created_at']);
    $now = new DateTime();
    $diffMinutes = ($now->getTimestamp() - $lastTime->getTimestamp()) / 60;

    return $diffMinutes >= ALERT_COOLDOWN_MINUTES;
}

/**
 * Dispara webhook para o n8n
 */
function triggerWebhook($payload) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => N8N_WEBHOOK_URL,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
        ],
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        error_log("Webhook error: " . $error);
        return false;
    }

    return $httpCode >= 200 && $httpCode < 300;
}

/**
 * Verifica leitura contra limites e gera alertas se necessário
 */
function checkThresholds($sensor, $temperature, $humidity) {
    require_once __DIR__ . '/db.php';

    $alertsTriggered = [];

    $checks = [
        ['field' => 'temperature', 'value' => $temperature, 'type' => 'temp_high', 'threshold' => $sensor['temp_max'], 'op' => '>',  'msg' => 'Temperatura acima do limite'],
        ['field' => 'temperature', 'value' => $temperature, 'type' => 'temp_low',  'threshold' => $sensor['temp_min'], 'op' => '<',  'msg' => 'Temperatura abaixo do limite'],
        ['field' => 'humidity',    'value' => $humidity,    'type' => 'hum_high',  'threshold' => $sensor['hum_max'],  'op' => '>',  'msg' => 'Umidade acima do limite'],
        ['field' => 'humidity',    'value' => $humidity,    'type' => 'hum_low',   'threshold' => $sensor['hum_min'],  'op' => '<',  'msg' => 'Umidade abaixo do limite'],
    ];

    foreach ($checks as $check) {
        if ($check['value'] === null) continue;

        $triggered = ($check['op'] === '>') 
            ? ($check['value'] > $check['threshold']) 
            : ($check['value'] < $check['threshold']);

        if ($triggered && canTriggerAlert($sensor['id'], $check['type'])) {
            // Gravar alerta no banco
            Database::execute(
                "INSERT INTO alerts (sensor_id, type, message, value, threshold) VALUES (?, ?, ?, ?, ?)",
                [$sensor['id'], $check['type'], $check['msg'], $check['value'], $check['threshold']]
            );

            // Buscar contatos do cliente
            $contacts = Database::query(
                "SELECT name, phone FROM contacts WHERE client_id = ? AND is_active = 1",
                [$sensor['client_id']]
            );

            $phones = array_column($contacts, 'phone');

            // Buscar nome do cliente
            $client = Database::queryOne("SELECT name, company FROM clients WHERE id = ?", [$sensor['client_id']]);

            // Payload para o webhook
            $payload = [
                'client'    => $client['company'] ?: $client['name'],
                'sensor'    => $sensor['device_id'],
                'location'  => $sensor['location'],
                'label'     => $sensor['label'],
                'type'      => $check['type'],
                'field'     => $check['field'],
                'value'     => $check['value'],
                'threshold' => $check['threshold'],
                'message'   => $check['msg'],
                'contacts'  => $phones,
                'timestamp' => date('Y-m-d\TH:i:s'),
            ];

            $webhookSent = triggerWebhook($payload);

            // Atualizar flag webhook_sent
            if ($webhookSent) {
                $alertId = Database::lastInsertId();
                Database::execute("UPDATE alerts SET webhook_sent = 1 WHERE id = ?", [$alertId]);
            }

            $alertsTriggered[] = $payload;
        }
    }

    return $alertsTriggered;
}
